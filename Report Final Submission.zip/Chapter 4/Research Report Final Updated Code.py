# ----------------------------------------------
# Chapter 4: Data Analysis and Findings – Solar PV South Africa
# ----------------------------------------------

# -------------------------------
# Installed Python Libraries
# -------------------------------
import os
import warnings
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
from datetime import datetime
from scipy import stats
from sklearn.model_selection import train_test_split, GridSearchCV, KFold
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
from prophet import Prophet
import openpyxl
from statsmodels.tsa.seasonal import seasonal_decompose
import joblib
import webbrowser

warnings.filterwarnings("ignore")
sns.set(style="whitegrid")

# -------------------------------
# Output Folders
# -------------------------------
output_dir = "Chapter4_Figures"
model_dir = "Chapter4_Models"
results_dir = "Chapter4_Results"

os.makedirs(output_dir, exist_ok=True)
os.makedirs(model_dir, exist_ok=True)
os.makedirs(results_dir, exist_ok=True)

# -------------------------------
# Figure Saving Helpers
# -------------------------------
fig_counter = 1

def save_fig(title=None, prefix="Figure_4"):
    """Save figure with auto-numbering."""
    global fig_counter
    filename = f"{prefix}_{fig_counter}.png"
    filepath = os.path.join(output_dir, filename)
    if title:
        plt.title(title, fontsize=12, fontweight="bold")
    plt.tight_layout()
    plt.savefig(filepath, dpi=300, bbox_inches="tight")
    print(f"📁 Saved figure: {filepath}")
    fig_counter += 1

def show_and_save(title=None, prefix="Figure_4"):
    """Show AND save figure."""
    save_fig(title=title, prefix=prefix)
    plt.show()

# ------------------------------------------------------------
# WORKFLOW ILLUSTRATION
# ------------------------------------------------------------
plt.figure(figsize=(12, 7))
plt.axis('off')

steps = [
    "Raw Dataset Import (Excel)",
    "Column Standardization",
    "Filter Last 5 Years",
    "Fill Missing Values",
    "Remove Outliers",
    "Descriptive Analysis",
    "Trend Analysis",
    "Forecasting (Prophet 2026–2030)",
    "Machine Learning Models",
    "Seasonal Decomposition",
    "Correlation Analysis",
    "Interactive Dashboard"
]

for i, step in enumerate(steps):
    plt.text(0.5, 1 - (i * 0.08), step, ha='center',
             fontsize=10, bbox=dict(boxstyle="round,pad=0.4",
             facecolor="skyblue", edgecolor="black"))
    if i < len(steps) - 1:
        plt.arrow(0.5, 1 - (i * 0.08) - 0.03,
                  0, -0.03, head_width=0.02, fc='black')

show_and_save("Workflow of Data Analysis & Forecasting for Solar PV (2021-2030)")

# ------------------------------------------------------------
# LOAD DATASET
# ------------------------------------------------------------
file_path = "ESK-Solar PV Data.xlsx"
df = pd.read_excel(file_path, engine="openpyxl")

df.columns = df.columns.str.strip().str.replace(" ", "_").str.lower()
print("\n📌 Columns Loaded:", df.columns.tolist())

# Sample structure
plt.figure(figsize=(12, 3))
plt.axis("off")
sample_table = plt.table(
    cellText=df.head().values,
    colLabels=df.columns,
    loc='center'
)
sample_table.auto_set_font_size(False)
sample_table.set_fontsize(10)
show_and_save("Sample Dataset Structure")

# ------------------------------------------------------------
# DATA CLEANING
# ------------------------------------------------------------
date_col = "date_time_hour_beginning"
pv_col = "pv"

df[date_col] = pd.to_datetime(df[date_col], errors="coerce", dayfirst=True)
df = df.dropna(subset=[date_col, pv_col]).sort_values(by=date_col)

# TRACK INITIAL ROWS
initial_rows = df.shape[0]
print(f"\n📌 INITIAL ROWS IN DATASET: {initial_rows}")

# Filter 5 years
latest_date = df[date_col].max()
start_date = latest_date - pd.DateOffset(years=5)

df_5yrs = df[df[date_col] >= start_date].copy()
rows_last5yrs = df_5yrs.shape[0]
print(f"📌 ROWS AFTER FILTERING LAST 5 YEARS ({start_date.date()} - {latest_date.date()}): {rows_last5yrs}")

# Numeric columns
numeric_cols = df_5yrs.select_dtypes(include=np.number).columns.tolist()
before_cleaning = df_5yrs.shape[0]
print(f"📌 ROWS BEFORE CLEANING: {before_cleaning}")

# Fill missing numeric values
df_5yrs[numeric_cols] = df_5yrs[numeric_cols].fillna(df_5yrs[numeric_cols].median())

# OUTLIER REMOVAL + TRACKING
total_outliers_removed = 0
for col in numeric_cols:
    z_scores = np.abs(stats.zscore(df_5yrs[col]))
    col_outliers = (z_scores >= 3).sum()
    total_outliers_removed += col_outliers
    df_5yrs = df_5yrs[z_scores < 3]

# After cleaning
after_cleaning = df_5yrs.shape[0]
rows_removed = before_cleaning - after_cleaning

print(f"📌 TOTAL OUTLIERS REMOVED: {total_outliers_removed}")
print(f"📌 ROWS AFTER CLEANING: {after_cleaning}")
print(f"📌 TOTAL ROWS REMOVED DURING CLEANING: {rows_removed}")

# Show data remaining figure
plt.figure(figsize=(6, 6))
plt.bar(["Remaining Data"], [after_cleaning], color="navy")
show_and_save("Total Data Points Remaining After Cleaning")

# ------------------------------------------------------------
# TERMINAL SUMMARY
# ------------------------------------------------------------
print("\n================ TERMINAL SUMMARY ================\n")
print(f"➡ Initial rows: {initial_rows}")
print(f"➡ After 5-year filter: {rows_last5yrs}")
print(f"➡ After cleaning: {after_cleaning}")
print(f"➡ Outliers removed: {total_outliers_removed}")
print(f"➡ Total removed: {rows_removed}")
print("\n=================================================\n")

# ------------------------------------------------------------
# BASIC VISUALISATIONS
# ------------------------------------------------------------
plt.figure(figsize=(12, 6))
plt.plot(df_5yrs[date_col], df_5yrs[pv_col], color='orange')
show_and_save("Solar PV Production Over Last 5 Years")

plt.figure(figsize=(8, 5))
sns.histplot(df_5yrs[pv_col], bins=50, kde=True)
show_and_save("Distribution of Solar PV Production")

plt.figure(figsize=(6, 4))
sns.boxplot(x=df_5yrs[pv_col], color='purple')
show_and_save("Box Plot of Solar PV Production")

# ------------------------------------------------------------
# DESCRIPTIVE STATISTICS
# ------------------------------------------------------------
desc_stats = df_5yrs[numeric_cols].describe()
desc_stats.to_csv(os.path.join(results_dir, "PV_Descriptive_Stats.csv"))

print("\n📌 DESCRIPTIVE STATS:\n", desc_stats)

# ------------------------------------------------------------
# TREND ANALYSIS
# ------------------------------------------------------------
df_5yrs['year'] = df_5yrs[date_col].dt.year
df_5yrs['month'] = df_5yrs[date_col].dt.month

yearly_total = df_5yrs.groupby('year')[pv_col].sum()
yearly_growth = yearly_total.pct_change() * 100

plt.figure(figsize=(12, 6))
plt.plot(df_5yrs[date_col], df_5yrs[pv_col], linewidth=1)
show_and_save("Solar PV Electricity Generation (2021-2025)")

plt.figure(figsize=(10, 5))
df_5yrs.groupby("month")[pv_col].mean().plot(kind="bar", color="gold")
show_and_save("Average Monthly PV Production (2021-2025)")

plt.figure(figsize=(8, 8))
plt.pie(yearly_total, labels=yearly_total.index, autopct='%1.1f%%')
show_and_save("Proportion of Solar PV Production Per Year")

# Export trend table
trend_table = pd.DataFrame({
    'Year': yearly_total.index,
    'Total_PV_MWh': yearly_total.values,
    'Growth_%': yearly_growth.values
})
trend_table.to_csv(os.path.join(results_dir, "PV_Annual_Trend.csv"), index=False)

# ------------------------------------------------------------
# PROPHET FORECAST (2026–2030)
# ------------------------------------------------------------
df_daily = df_5yrs.resample('D', on=date_col)[pv_col].sum().reset_index()
df_prophet = df_daily.rename(columns={date_col: 'ds', pv_col: 'y'})

model = Prophet(yearly_seasonality=True)
model.fit(df_prophet)

future = model.make_future_dataframe(periods=5*365)
forecast = model.predict(future)

# Show forecast plot
plt.figure(figsize=(12, 6))
plt.plot(df_prophet['ds'], df_prophet['y'], label="Actual")
plt.plot(forecast['ds'], forecast['yhat'], label="Forecast")
plt.legend()
show_and_save("Predicted vs Actual PV Output (2021-2030)")

# Annual forecast
forecast["year"] = forecast["ds"].dt.year
forecast_26_30 = forecast[(forecast["year"] >= 2026) & (forecast["year"] <= 2030)]

annual_forecast = forecast_26_30.groupby("year")[["yhat", "yhat_lower", "yhat_upper"]].sum()
annual_forecast.to_csv(os.path.join(results_dir, "PV_Forecast_2026_2030.csv"))

print("\n📌 PROPHET FORECAST TABLE:")
print(annual_forecast)

# ------------------------------------------------------------
# MACHINE LEARNING MODELS
# ------------------------------------------------------------
ml_cols = [c for c in ['installed_capacity', 'solar_irradiance', 'performance_ratio']
           if c in df_5yrs.columns]

if ml_cols:
    X = df_5yrs[ml_cols]
    y = df_5yrs[pv_col]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, shuffle=False, test_size=0.2, random_state=42)

    # Linear Regression
    lr = LinearRegression()
    lr.fit(X_train, y_train)
    y_pred_lr = lr.predict(X_test)

    # Random Forest
    rf = RandomForestRegressor(n_estimators=200, random_state=42)
    rf.fit(X_train, y_train)
    y_pred_rf = rf.predict(X_test)

    # ML Performance
    rmse_lr = mean_squared_error(y_test, y_pred_lr, squared=False)
    rmse_rf = mean_squared_error(y_test, y_pred_rf, squared=False)
    r2_lr = r2_score(y_test, y_pred_lr)
    r2_rf = r2_score(y_test, y_pred_rf)

    print("\n📌 MACHINE LEARNING RESULTS:")
    print(f"Linear Regression → RMSE={rmse_lr:.2f}, R²={r2_lr:.2f}")
    print(f"Random Forest     → RMSE={rmse_rf:.2f}, R²={r2_rf:.2f}")

    # Save models
    joblib.dump(lr, os.path.join(model_dir, "linear_regression_model.pkl"))
    joblib.dump(rf, os.path.join(model_dir, "random_forest_model.pkl"))

    # Plot results
    plt.figure(figsize=(8, 5))
    plt.scatter(y_test, y_pred_rf)
    plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--')
    show_and_save("Random Forest: Predicted vs Actual")

    plt.figure(figsize=(8, 5))
    sns.barplot(x=rf.feature_importances_, y=X.columns)
    show_and_save("Random Forest Feature Importance")

# ------------------------------------------------------------
# SEASONAL DECOMPOSITION
# ------------------------------------------------------------
df_daily2 = df_5yrs.set_index(date_col).resample("D")[pv_col].sum().fillna(0)

try:
    result = seasonal_decompose(df_daily2, model='additive', period=365)
    fig = result.plot()
    plt.tight_layout()
    show_and_save("Seasonal Decomposition of Daily PV Output")
except Exception as e:
    print("⚠️ Seasonal Decomposition Failed:", e)

# ------------------------------------------------------------
# CORRELATION MATRIX
# ------------------------------------------------------------
if len(numeric_cols) > 1:
    corr = df_5yrs[numeric_cols].corr()
    print("\n📌 CORRELATION MATRIX:\n", corr)

    plt.figure(figsize=(8, 6))
    sns.heatmap(corr, annot=True, cmap="coolwarm")
    show_and_save("Correlation Heatmap of Key Variables")

# ------------------------------------------------------------
# INTERACTIVE DASHBOARD
# ------------------------------------------------------------
dashboard = px.line(df_5yrs, x=date_col, y=pv_col, title="Solar PV Dashboard")
dashboard.write_html("Dashboard.html")
webbrowser.open("Dashboard.html")

print("\n🎉 Chapter 4 Completed — All Figures Generated, All Data Saved, and All Terminal Outputs Displayed.")
